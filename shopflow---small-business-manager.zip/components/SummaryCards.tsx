import React from 'react';
import { FinancialSummary } from '../types';
import { TrendingUp, TrendingDown, DollarSign, ShoppingBag, CreditCard, Wallet } from 'lucide-react';

interface SummaryCardsProps {
  summary: FinancialSummary;
}

const SummaryCards: React.FC<SummaryCardsProps> = ({ summary }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {/* Sales */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center space-x-4">
        <div className="p-3 bg-green-100 text-green-600 rounded-full">
          <ShoppingBag size={24} />
        </div>
        <div>
          <p className="text-sm text-slate-500 font-medium">Total Sales</p>
          <h3 className="text-2xl font-bold text-slate-800">${summary.totalSales.toLocaleString()}</h3>
        </div>
      </div>

      {/* Purchases */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center space-x-4">
        <div className="p-3 bg-blue-100 text-blue-600 rounded-full">
          <TrendingDown size={24} />
        </div>
        <div>
          <p className="text-sm text-slate-500 font-medium">Purchases</p>
          <h3 className="text-2xl font-bold text-slate-800">${summary.totalPurchases.toLocaleString()}</h3>
        </div>
      </div>

      {/* Expenses */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center space-x-4">
        <div className="p-3 bg-red-100 text-red-600 rounded-full">
          <CreditCard size={24} />
        </div>
        <div>
          <p className="text-sm text-slate-500 font-medium">Expenses</p>
          <h3 className="text-2xl font-bold text-slate-800">${summary.totalExpenses.toLocaleString()}</h3>
        </div>
      </div>

      {/* Net Profit */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center space-x-4">
        <div className={`p-3 rounded-full ${summary.netProfit >= 0 ? 'bg-indigo-100 text-indigo-600' : 'bg-orange-100 text-orange-600'}`}>
          <Wallet size={24} />
        </div>
        <div>
          <p className="text-sm text-slate-500 font-medium">Net Profit</p>
          <h3 className={`text-2xl font-bold ${summary.netProfit >= 0 ? 'text-indigo-900' : 'text-orange-700'}`}>
            ${summary.netProfit.toLocaleString()}
          </h3>
        </div>
      </div>
    </div>
  );
};

export default SummaryCards;