import React from 'react';
import { Transaction, TransactionType } from '../types';
import { ArrowUpRight, ArrowDownLeft, Trash2 } from 'lucide-react';

interface TransactionHistoryProps {
  transactions: Transaction[];
  onDelete: (id: string) => void;
}

const TransactionHistory: React.FC<TransactionHistoryProps> = ({ transactions, onDelete }) => {
  if (transactions.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-xl border border-slate-100 shadow-sm">
        <p className="text-slate-400">No transactions found. Add a new entry to get started.</p>
      </div>
    );
  }

  const getIcon = (type: TransactionType) => {
    if (type === TransactionType.SALE || type === TransactionType.INCOME) {
      return <div className="p-2 bg-green-100 text-green-600 rounded-full"><ArrowUpRight size={18} /></div>;
    }
    return <div className="p-2 bg-red-100 text-red-600 rounded-full"><ArrowDownLeft size={18} /></div>;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
        <h3 className="font-semibold text-slate-800">Recent Transactions</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm text-slate-600">
          <thead className="bg-slate-50 text-xs uppercase font-semibold text-slate-500">
            <tr>
              <th className="px-6 py-3">Type</th>
              <th className="px-6 py-3">Date</th>
              <th className="px-6 py-3">Category</th>
              <th className="px-6 py-3">Description</th>
              <th className="px-6 py-3 text-right">Amount</th>
              <th className="px-6 py-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {transactions.map((t) => (
              <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    {getIcon(t.type)}
                    <span className={`font-medium ${
                      (t.type === TransactionType.SALE || t.type === TransactionType.INCOME) ? 'text-green-700' : 'text-slate-700'
                    }`}>
                      {t.type}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-slate-500">{t.date}</td>
                <td className="px-6 py-4">
                  <span className="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600 border border-slate-200">
                    {t.category}
                  </span>
                </td>
                <td className="px-6 py-4 text-slate-700 truncate max-w-xs" title={t.description}>
                  {t.description}
                </td>
                <td className={`px-6 py-4 text-right font-bold whitespace-nowrap ${
                  (t.type === TransactionType.SALE || t.type === TransactionType.INCOME) ? 'text-green-600' : 'text-slate-800'
                }`}>
                  {(t.type === TransactionType.SALE || t.type === TransactionType.INCOME) ? '+' : '-'}{formatCurrency(t.amount)}
                </td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => onDelete(t.id)}
                    className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TransactionHistory;