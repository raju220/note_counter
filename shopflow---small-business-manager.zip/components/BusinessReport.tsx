import React, { useState } from 'react';
import { Transaction, TransactionType } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { generateBusinessReport } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';
import { Sparkles, FileText, Loader2, RefreshCw } from 'lucide-react';

interface BusinessReportProps {
  transactions: Transaction[];
}

const COLORS = ['#10b981', '#f59e0b', '#3b82f6', '#ef4444'];

const BusinessReport: React.FC<BusinessReportProps> = ({ transactions }) => {
  const [report, setReport] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Prepare Chart Data
  const typeData = [
    { name: 'Sales', value: transactions.filter(t => t.type === TransactionType.SALE).reduce((sum, t) => sum + t.amount, 0) },
    { name: 'Income', value: transactions.filter(t => t.type === TransactionType.INCOME).reduce((sum, t) => sum + t.amount, 0) },
    { name: 'Purchases', value: transactions.filter(t => t.type === TransactionType.PURCHASE).reduce((sum, t) => sum + t.amount, 0) },
    { name: 'Expenses', value: transactions.filter(t => t.type === TransactionType.EXPENSE).reduce((sum, t) => sum + t.amount, 0) },
  ].filter(d => d.value > 0);

  // Cash Flow Data (Last 7 days logic simplified for demo, grouping by type)
  const cashFlowData = [
    {
      name: 'Inflow',
      amount: transactions.filter(t => t.type === TransactionType.SALE || t.type === TransactionType.INCOME).reduce((sum, t) => sum + t.amount, 0),
    },
    {
      name: 'Outflow',
      amount: transactions.filter(t => t.type === TransactionType.PURCHASE || t.type === TransactionType.EXPENSE).reduce((sum, t) => sum + t.amount, 0),
    }
  ];

  const handleGenerateReport = async () => {
    setLoading(true);
    const aiReport = await generateBusinessReport(transactions);
    setReport(aiReport);
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Distribution Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Transaction Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={typeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                >
                  {typeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <RechartsTooltip formatter={(value: number) => `$${value.toLocaleString()}`} />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Cash Flow Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Cash Flow Overview</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cashFlowData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9"/>
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} tickFormatter={(val) => `$${val}`} />
                <RechartsTooltip cursor={{fill: '#f8fafc'}} formatter={(value: number) => `$${value.toLocaleString()}`} />
                <Bar dataKey="amount" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={60} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* AI Analysis Section */}
      <div className="bg-white p-6 rounded-xl shadow-lg border border-indigo-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none"></div>
        
        <div className="flex justify-between items-start mb-6 relative z-10">
          <div>
            <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              <Sparkles className="text-indigo-600" size={24} />
              AI Business Analyst
            </h3>
            <p className="text-slate-500 mt-1">Generate a comprehensive final report and actionable insights using Gemini AI.</p>
          </div>
          <button
            onClick={handleGenerateReport}
            disabled={loading || transactions.length === 0}
            className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 text-white rounded-lg font-medium shadow-md hover:shadow-lg transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? <Loader2 className="animate-spin" size={18} /> : <RefreshCw size={18} />}
            {report ? 'Update Report' : 'Generate Report'}
          </button>
        </div>

        {loading ? (
          <div className="py-12 flex flex-col items-center justify-center text-slate-400">
            <Loader2 className="animate-spin mb-3 text-indigo-500" size={32} />
            <p>Analyzing financial data...</p>
          </div>
        ) : report ? (
          <div className="prose prose-slate max-w-none bg-slate-50 p-6 rounded-xl border border-slate-100">
             <ReactMarkdown 
                components={{
                  h1: ({node, ...props}) => <h1 className="text-2xl font-bold text-slate-800 mb-4" {...props} />,
                  h2: ({node, ...props}) => <h2 className="text-xl font-semibold text-slate-800 mt-6 mb-3 border-b border-slate-200 pb-2" {...props} />,
                  h3: ({node, ...props}) => <h3 className="text-lg font-semibold text-indigo-700 mt-4 mb-2" {...props} />,
                  ul: ({node, ...props}) => <ul className="list-disc list-inside space-y-2 mb-4 text-slate-700" {...props} />,
                  li: ({node, ...props}) => <li className="marker:text-indigo-400" {...props} />,
                  strong: ({node, ...props}) => <strong className="font-semibold text-slate-900" {...props} />,
                  p: ({node, ...props}) => <p className="mb-4 leading-relaxed text-slate-700" {...props} />,
                }}
             >
                {report}
             </ReactMarkdown>
          </div>
        ) : (
          <div className="py-12 flex flex-col items-center justify-center text-slate-400 bg-slate-50 rounded-xl border border-slate-100 border-dashed">
            <FileText size={48} className="mb-3 text-slate-300" />
            <p>Click "Generate Report" to receive AI-driven insights about your shop's performance.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BusinessReport;