import { GoogleGenAI } from "@google/genai";
import { Transaction, TransactionType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateBusinessReport = async (transactions: Transaction[]): Promise<string> => {
  if (!transactions || transactions.length === 0) {
    return "No transactions available to analyze. Please add some entries to generate a report.";
  }

  // Prepare a summary for the prompt to save tokens and improve relevance
  const summary = transactions.reduce((acc, t) => {
    const amount = t.amount;
    if (t.type === TransactionType.SALE) acc.sales += amount;
    else if (t.type === TransactionType.PURCHASE) acc.purchases += amount;
    else if (t.type === TransactionType.EXPENSE) acc.expenses += amount;
    else if (t.type === TransactionType.INCOME) acc.otherIncome += amount;
    return acc;
  }, { sales: 0, purchases: 0, expenses: 0, otherIncome: 0 });

  const recentTransactions = transactions
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, 15)
    .map(t => `- ${t.date}: ${t.type} of $${t.amount} (${t.category}) - ${t.description}`)
    .join('\n');

  const prompt = `
    You are a professional business consultant for a small retail shop. 
    Analyze the following financial data and provide a "Final Report".
    
    Financial Summary:
    - Total Sales Revenue: $${summary.sales.toFixed(2)}
    - Total Inventory Purchases: $${summary.purchases.toFixed(2)}
    - Total Operational Expenses: $${summary.expenses.toFixed(2)}
    - Other Income: $${summary.otherIncome.toFixed(2)}
    - Net Profit: $${(summary.sales + summary.otherIncome - summary.purchases - summary.expenses).toFixed(2)}

    Recent Transactions Sample:
    ${recentTransactions}

    Please provide a concise but comprehensive Markdown report including:
    1. **Financial Health Check**: A brief assessment of profitability.
    2. **Key Observations**: Trends in spending or sales.
    3. **Actionable Recommendations**: 3 specific bullet points to improve the business.
    
    Keep the tone professional, encouraging, and clear. Format with nice Markdown headers.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an expert small business financial analyst.",
      }
    });

    return response.text || "Unable to generate report at this time.";
  } catch (error) {
    console.error("Error generating report:", error);
    return "Error connecting to AI service. Please check your network or API key.";
  }
};